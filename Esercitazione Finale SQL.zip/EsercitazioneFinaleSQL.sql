CREATE DATABASE ToysGroup;

USE ToysGroup;

/*Per la tabella "dimproduct" ho deciso di lasciare solamente le colonne utili all'esercitazione. 
Ho quindi volontariamente non inserito qualsiasi altra descrizione del prodotto (quali la misura, il colore, 
sottocategoria, età target del giocattolo, ...) */

CREATE TABLE dimproduct (
    ProductID INT AUTO_INCREMENT PRIMARY KEY
    , ProductName VARCHAR(100) NOT NULL
    , Category VARCHAR(50)
    , StandardCost DECIMAL(10,2)
    , UnitPrice DECIMAL(10,2)
);

-- Per "dimgeography" avrei potuto anche solo tenere "Country", ma mi sembrava troppo "magra"

CREATE TABLE dimgeography (
    GeographyID INT AUTO_INCREMENT PRIMARY KEY
    , Region VARCHAR(100)
    , Country VARCHAR(100)
    , City VARCHAR(100)
);

-- Come per "dimproduct", per "factsales" ho volontariamente omesso altre colonne.

CREATE TABLE factsales (
    SalesID INT AUTO_INCREMENT PRIMARY KEY
    , ProductID INT NOT NULL
    , GeographyID INT NOT NULL
    , OrderDate DATE NOT NULL
    , Quantity INT NOT NULL
    , FOREIGN KEY (ProductID) REFERENCES dimproduct(ProductID)
    , FOREIGN KEY (GeographyID) REFERENCES dimgeography(GeographyID)
);

-- Ho chiesto a ChatGPT di popolare le tabelle. Per dimproduct ho chiesto 100 records, per dimgeography 20 e per factsales 50.

INSERT INTO dimproduct (ProductName, Category, StandardCost, UnitPrice)
VALUES
('American Girl Doll', 'Action Figures', 35.24, 44.57),
('Musical Toy', 'Vehicles', 39.31, 59.12),
('Jigsaw Puzzle', 'Art & Crafts', 18.58, 32.38),
('Sketch Pad', 'Action Figures', 18.98, 22.6),
('Puzzle Game', 'Art & Crafts', 7.95, 27.45),
('Jigsaw Puzzle', 'Dolls', 11.17, 20.96),
('Toy Helicopter', 'Building Sets', 24.78, 30.31),
('American Girl Doll', 'Action Figures', 25.19, 33.81),
('Science Kit', 'Vehicles', 26.0, 44.31),
('Musical Toy', 'Dolls', 46.26, 57.48),
('Science Kit', 'Action Figures', 16.97, 29.4),
('Puzzle Game', 'Dolls', 36.1, 43.9),
('Hot Wheels Car', 'Vehicles', 31.78, 43.59),
('American Girl Doll', 'Vehicles', 45.28, 56.49),
('Hot Wheels Car', 'Action Figures', 5.65, 12.24),
('Lego Star Wars', 'Building Sets', 33.66, 48.75),
('Board Game', 'Games', 49.44, 63.88),
('Lego Star Wars', 'Dolls', 6.77, 12.59),
('RC Car', 'Building Sets', 48.9, 59.38),
('Play-Doh Set', 'Building Sets', 20.23, 32.81),
('Stuffed Bear', 'Action Figures', 18.5, 31.93),
('Lego Star Wars', 'Dolls', 38.88, 45.94),
('Toy Guitar', 'Vehicles', 31.04, 39.17),
('RC Car', 'Dolls', 9.26, 20.05),
('Lego Star Wars', 'Art & Crafts', 12.45, 21.62),
('Stuffed Bear', 'Action Figures', 48.99, 63.78),
('Toy Helicopter', 'Art & Crafts', 40.62, 58.25),
('Toy Guitar', 'Vehicles', 41.67, 59.29),
('Puzzle Game', 'Art & Crafts', 6.36, 14.63),
('Toy Guitar', 'Art & Crafts', 24.62, 28.31),
('Toy Helicopter', 'Dolls', 42.06, 50.14),
('Educational Blocks', 'Games', 8.33, 10.47),
('Board Game', 'Vehicles', 6.88, 16.56),
('Science Kit', 'Art & Crafts', 44.63, 64.13),
('Educational Blocks', 'Art & Crafts', 20.45, 35.02),
('Kre-O Set', 'Vehicles', 14.76, 31.91),
('Hot Wheels Car', 'Dolls', 27.61, 40.53),
('Kre-O Set', 'Games', 35.97, 43.88),
('Toy Guitar', 'Games', 31.35, 38.86),
('Play-Doh Set', 'Dolls', 6.43, 20.49),
('Transformer Toy', 'Games', 26.82, 46.5),
('American Girl Doll', 'Art & Crafts', 36.36, 41.24),
('Barbie Doll', 'Action Figures', 22.09, 29.4),
('American Girl Doll', 'Art & Crafts', 11.64, 26.91),
('Barbie Doll', 'Vehicles', 13.17, 21.42),
('Jigsaw Puzzle', 'Building Sets', 11.33, 26.66),
('Educational Blocks', 'Art & Crafts', 24.92, 32.67),
('Jigsaw Puzzle', 'Vehicles', 18.42, 29.59),
('Toy Guitar', 'Games', 15.41, 32.2),
('Musical Toy', 'Vehicles', 40.1, 44.12),
('Kre-O Set', 'Building Sets', 45.08, 54.28),
('Spiderman Figure', 'Art & Crafts', 36.36, 38.84),
('Educational Blocks', 'Dolls', 37.17, 54.38),
('Lego Star Wars', 'Vehicles', 38.43, 44.25),
('Musical Toy', 'Building Sets', 20.32, 30.34),
('Barbie Doll', 'Building Sets', 17.24, 25.79),
('Spiderman Figure', 'Vehicles', 28.7, 41.36),
('Puzzle Game', 'Art & Crafts', 12.25, 22.56),
('Toy Guitar', 'Vehicles', 29.67, 45.75),
('Transformer Toy', 'Vehicles', 31.31, 34.03),
('Sketch Pad', 'Building Sets', 45.76, 54.35),
('Toy Helicopter', 'Building Sets', 23.59, 29.95),
('Lego Star Wars', 'Art & Crafts', 45.42, 50.73),
('Barbie Doll', 'Building Sets', 28.55, 37.22),
('American Girl Doll', 'Games', 25.74, 44.02),
('Educational Blocks', 'Art & Crafts', 12.41, 19.82),
('Lego Star Wars', 'Dolls', 22.18, 31.75),
('Jigsaw Puzzle', 'Dolls', 11.22, 23.21),
('Jigsaw Puzzle', 'Building Sets', 7.48, 12.6),
('Spiderman Figure', 'Building Sets', 17.08, 33.61),
('Educational Blocks', 'Games', 17.8, 21.28),
('Toy Guitar', 'Dolls', 28.53, 34.0),
('Toy Guitar', 'Dolls', 17.1, 28.1),
('Kre-O Set', 'Building Sets', 33.29, 42.73),
('Spiderman Figure', 'Games', 49.09, 66.24),
('Toy Train Set', 'Vehicles', 49.6, 53.74),
('Lego Star Wars', 'Vehicles', 47.91, 57.8),
('Board Game', 'Art & Crafts', 26.41, 43.26),
('Hot Wheels Car', 'Building Sets', 13.55, 16.55),
('Educational Blocks', 'Games', 11.2, 13.29),
('Hot Wheels Car', 'Action Figures', 48.3, 53.51),
('Science Kit', 'Building Sets', 32.86, 51.18),
('Toy Guitar', 'Art & Crafts', 24.83, 40.36),
('Barbie Doll', 'Art & Crafts', 33.82, 43.97),
('Barbie Doll', 'Games', 49.82, 65.8),
('Jigsaw Puzzle', 'Action Figures', 5.12, 7.83),
('Hot Wheels Car', 'Building Sets', 37.62, 51.44),
('Lego Star Wars', 'Action Figures', 37.57, 52.72),
('Educational Blocks', 'Vehicles', 29.25, 46.52),
('Puzzle Game', 'Games', 41.67, 51.21),
('Musical Toy', 'Dolls', 11.92, 22.34),
('Toy Helicopter', 'Art & Crafts', 30.84, 48.1),
('Toy Guitar', 'Games', 23.44, 39.04),
('Transformer Toy', 'Games', 17.32, 30.01),
('RC Car', 'Action Figures', 11.27, 15.79),
('Toy Guitar', 'Games', 7.83, 14.92),
('Toy Guitar', 'Games', 35.82, 40.58),
('Toy Helicopter', 'Games', 15.88, 22.95),
('Puzzle Game', 'Action Figures', 36.92, 48.2),
('Educational Blocks', 'Building Sets', 25.78, 27.96);

INSERT INTO dimgeography (Region, Country, City)
VALUES
('North America', 'United States', 'New York'),
('North America', 'United States', 'Los Angeles'),
('North America', 'Canada', 'Toronto'),
('North America', 'Canada', 'Vancouver'),
('Europe', 'Italy', 'Rome'),
('Europe', 'Italy', 'Milan'),
('Europe', 'France', 'Paris'),
('Europe', 'Germany', 'Berlin'),
('Asia', 'Japan', 'Tokyo'),
('Asia', 'Japan', 'Osaka'),
('Asia', 'China', 'Beijing'),
('Asia', 'India', 'Mumbai'),
('South America', 'Brazil', 'Rio de Janeiro'),
('South America', 'Argentina', 'Buenos Aires'),
('Africa', 'South Africa', 'Cape Town'),
('Africa', 'Egypt', 'Cairo'),
('Oceania', 'Australia', 'Sydney'),
('Oceania', 'Australia', 'Melbourne'),
('Europe', 'United Kingdom', 'London'),
('Europe', 'Spain', 'Madrid');

INSERT INTO factsales (ProductID, GeographyID, OrderDate, Quantity)
VALUES
(34, 14, '2024-03-01', 20),
(23, 9, '2024-02-16', 9),
(74, 13, '2024-01-29', 17),
(92, 1, '2024-07-21', 10),
(10, 20, '2024-08-26', 10),
(25, 19, '2024-09-05', 19),
(92, 8, '2024-06-08', 20),
(83, 7, '2024-03-15', 4),
(41, 8, '2024-09-10', 8),
(7, 5, '2024-08-24', 11),
(3, 2, '2024-02-01', 17),
(80, 11, '2024-11-10', 4),
(34, 13, '2024-05-17', 11),
(47, 20, '2024-10-19', 3),
(97, 4, '2024-07-24', 12),
(8, 7, '2024-07-09', 1),
(95, 3, '2024-08-11', 17),
(99, 5, '2024-01-15', 11),
(68, 8, '2024-10-20', 5),
(100, 16, '2023-12-17', 15),
(22, 16, '2024-11-01', 5),
(38, 7, '2024-03-28', 12),
(72, 17, '2024-11-17', 6),
(5, 9, '2024-10-05', 14),
(66, 18, '2024-08-19', 20),
(66, 7, '2024-07-08', 4),
(43, 8, '2024-01-23', 6),
(2, 14, '2024-08-10', 13),
(59, 16, '2024-07-07', 6),
(94, 6, '2024-07-29', 8),
(61, 4, '2023-12-02', 10),
(68, 11, '2024-06-24', 7),
(49, 3, '2024-03-10', 4),
(64, 7, '2024-07-30', 19),
(65, 5, '2024-06-20', 17),
(61, 12, '2024-07-11', 9),
(13, 2, '2024-05-08', 4),
(77, 16, '2024-05-09', 16),
(88, 9, '2024-09-17', 10),
(91, 2, '2023-12-05', 17),
(71, 4, '2024-11-12', 20),
(77, 13, '2024-06-15', 12),
(70, 2, '2024-01-25', 8),
(63, 12, '2024-06-04', 12),
(50, 18, '2024-01-21', 16),
(57, 4, '2023-12-11', 1),
(69, 17, '2024-09-23', 6),
(89, 12, '2024-01-09', 10),
(33, 1, '2024-04-04', 12),
(67, 12, '2024-02-21', 15);

/* Mi creo una view complessiva del database che potrà essere utile allo svolgimento delle tracce.
Voglio isolare i dati dei soli prodotti venduti. */

CREATE VIEW 
	vw_fullsalesdata
    AS (
SELECT
    s.SalesID
    , s.OrderDate
    , s.Quantity
    , p.ProductID
    , p.ProductName
    , p.Category
    , p.StandardCost
    , p.UnitPrice
    , (s.Quantity * p.UnitPrice) AS SalesAmount
    , ((p.UnitPrice * s.Quantity) - (p.StandardCost * s.Quantity)) AS Profit
    , g.GeographyID
    , g.Region
    , g.Country
    , g.City
	FROM 
    factsales AS s
	INNER JOIN
    dimproduct AS p 
    ON 
    s.ProductID = p.ProductID
	LEFT JOIN
    dimgeography AS g 
    ON 
    s.GeographyID = g.GeographyID
    );
    
-- 1. Verificare che i campi definiti come PK siano univoci.
/* Userò due metodologie.
Il primo metodo prevede mettere a paragone il conteggio dei record totali della tabella con i singoli record della PK, 
la quale non ha valori univoci in quanto è stato assegnato "AUTO_INCREMENT". Pertanto, non serve un DISTINCT*/

SELECT
	COUNT(*) AS RecordTotali
    , COUNT(p.ProductID) AS RecordPK
FROM
	dimproduct AS p; -- OUTPUT: 100 records per ognuno. 
    
/* Per la seconda tabella, raggrupperò i record per le PK e chiederò di mostrare solo quelle con valori superiori a 1.
Se il risultato è 0 records, i valori saranno univoci. */

SELECT
	g.GeographyID AS PK
    , COUNT(*) AS Conteggio
FROM
	dimgeography AS g
    GROUP BY
    PK
    HAVING
    Conteggio > 1; -- OUTPUT: 0 records
    
-- Procedo alla verifica dell'ultima tabella utilizzando il primo metodo, più veloce e intuitivo a parer mio.

SELECT
	COUNT(*) AS RecordTotali
    , COUNT(s.SalesID) AS RecordPK
FROM
	factsales AS s; -- OUTPUT: 50 records per ognuno.
    
-- 2. Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. 

SELECT 
    ProductName AS NomeProdotto
    , YEAR(OrderDate) AS AnnoVendita
    , SUM(SalesAmount) AS FatturatoTotale
    , SUM(Profit) AS ProfittoTotale
FROM 
    vw_fullsalesdata
GROUP BY 
    NomeProdotto
    , AnnoVendita
ORDER BY 
    AnnoVendita
    , FatturatoTotale DESC;
    
-- Senza l'aiuto di una VIEW, bisogna fare una INNER JOIN per ricavare i soli prodotti venduti.

SELECT
	p.ProductName AS NomeProdotto
    , YEAR(s.OrderDate) AS AnnoVendita
    , SUM(s.Quantity * p.UnitPrice) AS FatturatoTotale
FROM
	factsales AS s
    JOIN
    dimproduct AS p
    ON
    s.ProductID = p.ProductID
    GROUP BY 
    NomeProdotto
    , AnnoVendita
	ORDER BY 
    AnnoVendita
    , FatturatoTotale DESC; -- Gli OUTPUT di entrambi i metodi sono uguali.
    
-- 3. Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. 

SELECT
	Country AS Stato
    , YEAR(OrderDate) AS AnnoVendita
    , SUM(SalesAmount) AS FatturatoTotale
    , SUM(Profit) AS ProfittoTotale
FROM
	vw_fullsalesdata
    GROUP BY
    Stato
    , AnnoVendita
    ORDER BY
    AnnoVendita
    , FatturatoTotale DESC;
    
/* 4. Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?
La categoria di articoli maggiormente richiesta dal mercato è quella che ha venduto in quantità maggiore. */

SELECT
	Category AS CategoriaProdotto
    , SUM(Quantity) AS UnitaVendute
FROM
	vw_fullsalesdata
    GROUP BY
    CategoriaProdotto
    ORDER BY
    UnitaVendute DESC
    -- Si potrebbe aggiungere "LIMIT 1" per estrarre solamente la categoria più venduta.
    ;
    
/* 5. Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. 
I prodotti invenduti sono quei prodotti che non hanno corrispondenza nella tabella factsales (e quindi con SalesID nullo). */

-- METODO 1: Una LEFT JOIN per preservare tutti i prodotti e una WHERE per estrapolare quelli non venduti.

SELECT 
	p.ProductID AS CodiceProdotto
    , p.ProductName AS NomeProdotto
    , COALESCE(s.SalesID, 'INVENDUTO') AS CodiceVendita
FROM
	dimproduct AS p
    LEFT JOIN
    factsales AS s
    ON
    p.ProductID = s.ProductID
    WHERE
    s.SalesID IS NULL;
    
-- METODO 2: Utilizziamo una subquery con la VIEW. Tutti i prodotti non presenti nella nostra VIEW, saranno quelli invenduti.

SELECT 
	p.ProductID AS CodiceProdotto
    , p.ProductName AS ProdottoInvenduto
FROM
	dimproduct AS p
    WHERE
    p.ProductID NOT IN (SELECT 
							ProductID
						FROM
							vw_fullsalesdata); -- Gli output dei due metodi coincidono.
    
-- 6. Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).
    
SELECT
	ProductID AS CodiceProdotto
    , ProductName AS NomeProdotto
    , MAX(OrderDate) AS DataUltimoOrdine
FROM
	vw_fullsalesdata
    GROUP BY
    CodiceProdotto
    ORDER BY
    DataUltimoOrdine DESC;
    
-- Grazie per l'attenzione :)